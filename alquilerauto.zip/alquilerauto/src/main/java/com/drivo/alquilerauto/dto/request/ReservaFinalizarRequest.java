package com.drivo.alquilerauto.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record ReservaFinalizarRequest(

        @NotNull(message = "El kilometraje de fin es obligatorio")
        @Min(value = 0, message = "El kilometraje no puede ser negativo")
        Integer kilometrajeFin,

        String observaciones,

        String usuario
) {}
